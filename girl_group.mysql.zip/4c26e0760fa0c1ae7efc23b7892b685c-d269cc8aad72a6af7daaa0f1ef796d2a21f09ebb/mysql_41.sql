CREATE TABLE girl_group
(
  _id INT PRIMARY KEY AUTO_INCREMENT,
  name VARCHAR(32) NOT NULL,
  debut DATE NOT NULL,
  hit_song_id INT
);

INSERT INTO girl_group (name, debut, hit_song_id) 
VALUES ('원더걸스', '2007-09-12', 101);
INSERT INTO girl_group (name, debut, hit_song_id) 
VALUES ('소녀시대', '2009-06-03', 102);
INSERT INTO girl_group (name, debut, hit_song_id) 
VALUES ('카라', '2009-07-30', 103);
INSERT INTO girl_group (name, debut, hit_song_id) 
VALUES ('브라운아이드걸스', '2008-01-17', 104);
INSERT INTO girl_group (name, debut, hit_song_id) 
VALUES ('다비치', '2009-02-27', 105);
INSERT INTO girl_group (name, debut, hit_song_id) 
VALUES ('2NE1', '2009-07-08', 107);
INSERT INTO girl_group (name, debut, hit_song_id) 
VALUES ('f(x)', '2011-04-20', 109);
INSERT INTO girl_group (name, debut, hit_song_id) 
VALUES ('시크릿', '2011-01-06', 110);
INSERT INTO girl_group (name, debut, hit_song_id) 
VALUES ('레인보우', '2010-08-12', 111);
INSERT INTO girl_group (name, debut) 
VALUES ('에프터 스쿨', '2009-11-25');
INSERT INTO girl_group (name, debut) 
VALUES ('포미닛', '2009-08-28');

CREATE TABLE professor
(
     _id INT AUTO_INCREMENT,
     name VARCHAR(32) NOT NULL,
     belong VARCHAR(12) DEFAULT 'FOO',
     phone VARCHAR(12),
     PRIMARY KEY(_id)
) ENGINE=INNODB;

INSERT INTO professor
(name, belong, phone)
VALUES('유재석', 'IDE','01112345678');

INSERT INTO professor
(name, belong, phone)
VALUES('황영조', 'MSE', '01121342443');

INSERT INTO professor
(name, belong, phone)
VALUES('케이멀', 'ESE', '01123424343');

INSERT INTO professor
(_id, name, belong, phone)
VALUES(256, '호날두', 'IME', '01134343222');

INSERT INTO professor
(name, belong, phone)
VALUES( '리오넬', 'IDE', '01123432432');
SELECT _id, belong, phone FROM professor;
SELECT * FROM professor;