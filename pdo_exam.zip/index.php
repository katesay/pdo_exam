   
<!DOCTYPE html>
<html lang="kr">
<head>
<meta charset="utf-8">
<title>PDO로 데이터베이스에 접속한다</title>
<link href="../../css/style.css" rel="stylesheet">
</head>
<body>
<div>

    <?php
        $libPath = "./lib/";
        
        include $libPath. "dbuser.php";
        include $libPath. "dbcon.php";
        include $libPath. "util.php";
    ?>
    <?
        $pdo = dbConnect($dsn, $user, $password, $dbName)
    ?><br>
    <?php
        try {
            // SQL문을 만든다(모든 레코드)
            $sql = "SELECT * FROM member";
            // PDO에 쿼리 문장을 등록한다
            $stm = $pdo->prepare($sql);
            // SQL 문을 실행한다
            $stm->execute();
            // 결과 얻기(연관 배열로 반환한다)
            $result = $stm->fetchAll(PDO::FETCH_ASSOC);

            foreach ($result as $row){
              // １행씩 테이블에 넣는다
              echo "<tr>";
              echo "<td>", es($row['id']), "</td>";
              echo "<td>", es($row['name']), "</td>";
              echo "<td>", es($row['age']), "</td>";
              echo "<td>", es($row['sex']), "</td>";
              echo "</tr>";
            }
            echo "</tbody>";
            echo "</table>";
        } catch (Exception $e) {
            echo '<span class="error">오류가 있습니다. </span><br>';
            echo $e->getMessage();
            exit();
        }

    ?>
     <?php
        dbClose($pdo);
     ?>


</div>
</body>
</html>