
<html>
    <body>
        <form action="pds_process.php" method="POST" enctype="multipart/form-data">
            <input type="file" name="image"  /><br>
            <input type="submit"/>
        </form>

    </body>
</html>