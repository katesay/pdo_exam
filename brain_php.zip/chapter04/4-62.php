<?
	echo round(3.3); // 3
	echo round(3.5); // 4
	echo round(1.23456, 3); //1.235
	echo round(123456, -3); //123000
?>