<?
	echo rand(); // 205
	echo rand(1, 10); // 10
	echo rand(40000, 50000); // 44732
?>