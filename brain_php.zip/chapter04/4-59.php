<?
	echo pow(1, 1000); // 1
	echo pow(-1, 2); // 1
	echo pow(2, 3); // 8
?>