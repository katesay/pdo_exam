<?
	$string = "brown";
	echo md5($string);
?>