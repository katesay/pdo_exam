<?
	$path = "/home/httpd/html/index.php";

	echo basename ($path) . "<BR>";
	echo basename ($path,".php");
?>