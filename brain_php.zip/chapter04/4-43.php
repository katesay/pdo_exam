<?
	$var = TRUE;
	$var ? print('TRUE'): print('FALSE');
?>