<?
	echo microtime();
	echo "<BR>";
	echo microtime(TRUE);
?>