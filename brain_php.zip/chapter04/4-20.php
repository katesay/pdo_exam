<?
	echo filetype("/etc/passwd") . "<BR>";
	echo filetype("/etc/");
?>