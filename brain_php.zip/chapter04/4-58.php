<?
	echo floor(3.00); // 3
	echo floor(3.3); // 3
	echo floor(-3.3); // -4
?>