<?
	echo ceil(3.00); // 3
	echo ceil(3.3); // 4
	echo ceil(-3.3); // -3
?>