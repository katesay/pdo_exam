<?
	$html = "<font color='%font_color%'>������</font>";
	$html = str_replace("%font_color%", "blue", $html);
	echo $html;
?>