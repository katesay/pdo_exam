<?
	echo date("Y-m-d", mktime(0, 0, 0, 12, 32, 2008)) . "<BR>";
	echo date("Y-m-d", mktime(0, 0, 0, 13, 1, 2008)) . "<BR>";
	echo date("Y-m-d", mktime(0, 0, 0, 1, 1, 2009)) . "<BR>";
?>