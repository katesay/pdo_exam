<?
	echo mt_rand(); // 1930233306
	echo mt_rand (1, 10); // 9
	echo mt_rand (40000, 50000); // 43758
?>