<?
	$string = "Hello. My name is <B>Brown</B>.";

	echo htmlentities($string);
?>