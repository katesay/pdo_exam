<?
	$path = "/home/httpd/htdocs/index.php";
	echo dirname ($path);
?>