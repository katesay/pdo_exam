<?
	$float = 12.345;

	$result = sprintf("�Ҽ� : %.3f", $float);
	echo $result;
?>