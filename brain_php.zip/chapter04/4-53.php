<?
	$email = 'happybrown@naver.com';
	$domain = strstr($email, '@');
	echo $domain; //@naver.com�� ��µ�
?>