<?
	chmod("/somedir/somefile", 0755);
?>