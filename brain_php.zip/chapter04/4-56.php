<?
	echo abs(3); // 3
	echo abs(-3); // 3
	echo abs(-3.3); // 3.3
?>