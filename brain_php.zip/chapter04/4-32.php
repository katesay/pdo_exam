<?
	rename("/tmp/tmp_file.txt", "/var/www/file.txt");
?>