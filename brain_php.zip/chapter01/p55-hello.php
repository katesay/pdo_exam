<?
	echo "Hello, PHP!";
?>