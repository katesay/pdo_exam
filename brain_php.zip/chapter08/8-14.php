<HTML>
<BODY>
<FORM METHOD="POST" ACTION="login_process.php">
ID : <INPUT TYPE="TEXT" NAME="userid"><BR>
PW : <INPUT TYPE="PASSWORD" NAME="userpw"><BR>
<INPUT TYPE="SUBMIT" VALUE="Ȯ��">
</BODY>
</HTML>