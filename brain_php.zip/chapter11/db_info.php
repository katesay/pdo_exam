<?
	$conn = mysql_connect("localhost", "아이디", "패스워드");
	mysql_select_db("디비이름",$conn);
?>