<?
	$fruits = array ('a'=>"lemon", 'b'=>"orange", "banana", "apple");
	asort ($fruits);
	echo "<pre>";
	print_r($fruits);
	echo "</pre>";
?>