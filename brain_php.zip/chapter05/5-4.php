<?
	$arr = array("name"=>"brown", 5=>"����", "ezphp.net");
	echo $arr[5];
	echo "<BR>";
	echo $arr[6];
?>