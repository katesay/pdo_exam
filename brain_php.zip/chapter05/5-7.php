<?
	$arr = array( array(100,100,80),
				  array(90,100,90),
				  array(80,80,100)
	);

	echo $arr[0][0] .','.$arr[0][1] .','.$arr[0][2];
	echo '<BR>';
	echo $arr[1][0] .','.$arr[1][1] .','.$arr[1][2];
	echo '<BR>';
	echo $arr[2][0] .','.$arr[2][1] .','.$arr[2][2];
?>