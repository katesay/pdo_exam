<?
	$fruits = array ('a'=>"lemon", 'b'=>"orange", "banana", "apple");
	sort ($fruits);
	echo "<pre>";
	print_r($fruits);
	echo "</pre>";
?>