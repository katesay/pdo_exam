<?
	$fruits = array ('a'=>"lemon", 'b'=>"orange", 'c'=>"banana", 'd'=>"apple");
	ksort ($fruits);
	echo "<pre>";
	print_r($fruits);
	echo "</pre>";
?>