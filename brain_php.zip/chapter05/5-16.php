<?
	$arr = array ("img12.png", "img10.png", "img2.png", "img1.png");
	natsort($arr);
	echo "<pre>";
	print_r($arr);
	echo "</pre>";
?>