<?
	$arr = array("name"=>"brown", 7=>"����");
	echo $arr[name];
	echo "<BR>";
	echo $arr[7];
?>