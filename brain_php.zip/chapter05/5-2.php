<?
	$arr = array("brown", "����");
	echo $arr[0];
	echo "<BR>";
	echo $arr[1];
?>