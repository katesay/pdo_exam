<?
	$arr['name'] = 'brown';
	$arr[] = 15;
	echo $arr['name'];
	echo "<BR>";
	echo $arr[0];
?>