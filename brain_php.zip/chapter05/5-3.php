<?
	$arr = array("name"=>"brown", "����");
	echo $arr[name];
	echo "<BR>";
	echo $arr[0];
?>