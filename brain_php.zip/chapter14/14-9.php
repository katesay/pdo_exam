<?
	mysql_connect("localhost","brown","1234");
?>