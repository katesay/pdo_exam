<?
	$math = 85;

	if ( $math >= 90 ) echo "��";
	elseif ($math >= 80 && $math < 90) echo "��";
	elseif ($math >= 70 && $math < 80) echo "��";
	elseif ($math >= 60 && $math < 70) echo "��";
	else echo "��";
?>