<?
	function return_array()
	{
		return array(0, 1, 2);
	}

	$array = return_array();
	echo "$array[0], $array[1], $array[2]";
?>