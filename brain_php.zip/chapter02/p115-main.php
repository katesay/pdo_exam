<?
	include 'head.html';
	echo 'main.php �Դϴ�.<BR>';
	include 'tail.html';
?>