<?
	$i = 1;

	while (1) {
		if ($i > 10) break;
		echo $i++;
	}
?>