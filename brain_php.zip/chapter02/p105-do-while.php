<?
	$i = 1;

	do {
		echo $i++;
	} while ( $i <= 10 );
?>