<?
	function sum($a, $b)
	{
		return $a+$b;
	}

	$result = sum(3, 4);
	echo $result;
?>