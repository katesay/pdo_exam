<?
	function ezphp_net ($url = "http://ezphp.net")
	{
		return "Ȩ������ �ּ� : $url<BR>";
	}

	echo ezphp_net ();
	echo ezphp_net ("http://www.ezphp.net");
?>