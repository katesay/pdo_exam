<?
	$i = 100;

	do {
		echo $i++;
	} while ( $i <= 10 );
?>