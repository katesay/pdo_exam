<?
	include 'inc.php';
	echo $name;
?>