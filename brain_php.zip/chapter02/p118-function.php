<?
	function sum($a, $b)
	{
		return $a+$b;
	}

	$result = sum(3, 4);
	echo $result . "<BR>";
	$result = sum(5, 7);
	echo $result . "<BR>";
?>