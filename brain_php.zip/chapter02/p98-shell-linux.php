<?
	$output = `ls -al`;
	echo "<pre>$output</pre>";
?>