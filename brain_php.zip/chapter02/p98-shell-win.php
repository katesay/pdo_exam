<?
	$output = `dir`;
	echo "<pre>$output</pre>";
?>