<FORM ACTION="insert.php" METHOD="POST">
<TABLE BORDER=1 WIDTH=500>
	<TR>
		<TD>�̸�</TD><TD><INPUT TYPE="TEXT" NAME="name"></TD>
		<TD>��й�ȣ</TD><TD><INPUT TYPE="PASSWORD" NAME="pass"></TD>
	</TR>
	<TR>
		<TD COLSPAN=4>
			<TEXTAREA NAME="content" COLS=65 ROWS=5></TEXTAREA>
		</TD>
	</TR>
	<TR>
		<TD COLSPAN=4 align=right><INPUT TYPE="SUBMIT" VALUE=" Ȯ�� "></TD>
	</TR>
</TABLE>